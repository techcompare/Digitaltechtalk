import React, { useMemo } from 'react';
import type { Tool } from '../types';
import { BrainCircuitIcon, ImageIcon, CodeIcon, VideoIcon, MusicIcon, AutomationIcon, DefaultIcon } from './icons';

interface ToolCardProps {
  tool: Tool;
  index: number;
}

const iconMappings = [
  { keywords: ['brain', 'text', 'language', 'writing', 'llm', 'generate'], component: BrainCircuitIcon },
  { keywords: ['image', 'art', 'design', 'photo', 'visual'], component: ImageIcon },
  { keywords: ['code', 'developer', 'programming', 'script'], component: CodeIcon },
  { keywords: ['video', 'film', 'animation', 'movie'], component: VideoIcon },
  { keywords: ['music', 'audio', 'sound', 'song'], component: MusicIcon },
  { keywords: ['automation', 'productivity', 'workflow', 'assistant'], component: AutomationIcon },
];

const getPricingClasses = (pricing: string): string => {
    const p = pricing.toLowerCase();
    // Order is important: check for more specific terms first.
    if (p.includes('trial')) {
        return 'bg-yellow-900/70 text-yellow-300 border-yellow-700/50';
    }
    if (p.includes('freemium')) {
        return 'bg-gray-800 text-gray-400 border-gray-700';
    }
    if (p.includes('free')) {
        return 'bg-green-900/70 text-green-300 border-green-700/50';
    }
    if (p.includes('paid') || p.includes('premium')) {
        return 'bg-blue-900/70 text-blue-300 border-blue-700/50';
    }
    return 'bg-gray-800 text-gray-400 border-gray-700'; // Default fallback
};


const ToolCard: React.FC<ToolCardProps> = ({ tool, index }) => {
  const IconComponent = useMemo(() => {
    const iconKeyword = tool.icon.toLowerCase().trim();
    for (const mapping of iconMappings) {
      if (mapping.keywords.some(keyword => iconKeyword.includes(keyword))) {
        return mapping.component;
      }
    }
    return DefaultIcon;
  }, [tool.icon]);

  return (
    <a
      href={tool.websiteUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="flex flex-col group bg-gray-900/50 border border-gray-800 rounded-lg p-6 hover:bg-gray-800/60 hover:border-blue-500/50 transition-all duration-300 transform hover:-translate-y-1 animate-card-appear"
      style={{ animationDelay: `${index * 75}ms` }}
    >
      <div className="flex-grow">
        <div className="flex items-start justify-between mb-3">
            <div className="flex items-center">
                <IconComponent className="w-7 h-7 text-blue-400 mr-4 flex-shrink-0" />
                <h3 className="text-xl font-semibold text-gray-100">{tool.name}</h3>
            </div>
            <div className="text-blue-400 opacity-0 group-hover:opacity-100 transition-opacity duration-300 ml-4 flex-shrink-0">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M7 17l9.2-9.2M17 17V7H7"/>
                </svg>
            </div>
        </div>
        <p className="text-gray-400 text-sm leading-relaxed">{tool.description}</p>
      </div>
      <div className="mt-4 pt-4 border-t border-gray-800/50 flex items-center flex-wrap gap-2">
        <span className="inline-block bg-gray-800 text-purple-300 text-xs font-medium px-3 py-1 rounded-full">
          {tool.category}
        </span>
        <span className={`inline-block border text-xs font-medium px-3 py-1 rounded-full ${getPricingClasses(tool.pricing)}`}>
            {tool.pricing}
        </span>
      </div>
    </a>
  );
};

export default ToolCard;