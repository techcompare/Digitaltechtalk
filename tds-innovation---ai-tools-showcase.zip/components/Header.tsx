import React from 'react';

interface HeaderProps {
  currentRoute: string;
}

const navLinks = [
  { href: '#/', label: 'Home' },
  { href: '#/search', label: 'Search' },
  { href: '#/about', label: 'About' },
  { href: '#/submit', label: 'Submit a Tool' },
];

const Header: React.FC<HeaderProps> = ({ currentRoute }) => {
  return (
    <header className="py-6 px-4 text-center border-b border-gray-800/50">
      <div className="container mx-auto max-w-6xl">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="text-center md:text-left mb-4 md:mb-0">
            <h1 className="text-3xl md:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-500">
              TDS Innovation
            </h1>
            <p className="text-md md:text-lg text-gray-400">
              Curated Showcase of Trending AI Tools
            </p>
          </div>
          <nav>
            <ul className="flex items-center space-x-4 md:space-x-6">
              {navLinks.map(({ href, label }) => (
                <li key={href}>
                  <a
                    href={href}
                    className={`text-gray-300 hover:text-blue-400 transition-colors duration-300 pb-1 ${
                      currentRoute === href ? 'text-blue-400 border-b-2 border-blue-400' : 'border-b-2 border-transparent'
                    }`}
                  >
                    {label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;