
import React from 'react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className="py-6 text-center text-gray-500 mt-16">
      <div className="container mx-auto">
        <p>&copy; {currentYear} TDS Innovation. All rights reserved.</p>
        <p className="text-sm mt-1">Powered by AI and Human Ingenuity</p>
      </div>
    </footer>
  );
};

export default Footer;
