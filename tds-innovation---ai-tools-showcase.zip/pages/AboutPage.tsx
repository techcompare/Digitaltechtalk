import React from 'react';

const AboutPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto text-left">
      <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-8 md:p-12">
        <h2 className="text-3xl md:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-500 mb-6">
          About TDS Innovation
        </h2>
        <div className="space-y-6 text-gray-300 leading-relaxed">
          <p>
            TDS Innovation stands at the forefront of the artificial intelligence revolution. Our mission is to demystify AI and make its powerful tools accessible to everyone—from seasoned developers and entrepreneurs to curious creators and students. We believe that by curating and showcasing the most impactful AI technologies, we can empower individuals and organizations to innovate, create, and solve the challenges of tomorrow.
          </p>
          <p>
            This showcase is a living directory of the latest and most significant AI tools on the market. Powered by Google's Gemini API, our platform dynamically fetches, categorizes, and presents a curated list of trending technologies. We go beyond simple listings by providing concise, valuable insights into what each tool does, who it's for, and how it can be used.
          </p>
          <p>
            Our commitment is to maintain an up-to-date, unbiased, and comprehensive resource. Whether you're looking for a tool to generate stunning visuals, write flawless code, compose music, or automate complex workflows, TDS Innovation is your trusted guide in the ever-evolving landscape of artificial intelligence.
          </p>
          <p className="font-semibold text-gray-100 pt-4 border-t border-gray-700/50">
            Join us on this exciting journey as we explore the boundless possibilities of AI.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;