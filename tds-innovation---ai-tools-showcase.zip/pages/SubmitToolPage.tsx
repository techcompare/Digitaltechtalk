import React, { useState } from 'react';
import { generateSubmissionResponse } from '../services/geminiService';

const SubmitToolPage: React.FC = () => {
  const [toolName, setToolName] = useState('');
  const [toolUrl, setToolUrl] = useState('');
  const [description, setDescription] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [submissionResponse, setSubmissionResponse] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null); // Clear previous errors on a new submission attempt.

    // 1. Validate Tool Name
    if (!toolName.trim()) {
        setError('Tool Name is required.');
        return;
    }

    // 2. Validate Website URL
    if (!toolUrl.trim()) {
        setError('Website URL is required.');
        return;
    }

    try {
        new URL(toolUrl);
    } catch (_) {
        setError('Please enter a valid Website URL (e.g., https://example.com).');
        return;
    }

    // All validation passed, proceed with submission
    setIsLoading(true);
    setSubmissionResponse(null);

    try {
        const response = await generateSubmissionResponse(toolName);
        setSubmissionResponse(response);
        // Reset form
        setToolName('');
        setToolUrl('');
        setDescription('');
    } catch (err) {
        setError('An error occurred while submitting. Please try again.');
    } finally {
        setIsLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="text-center mb-10">
        <h2 className="text-3xl font-bold text-gray-100">Submit an AI Tool</h2>
        <p className="text-gray-400 mt-2">Know an amazing AI tool? Share it with the community!</p>
      </div>
      
      {submissionResponse ? (
        <div className="bg-gray-900/50 border border-blue-500/50 rounded-lg p-8 text-center">
            <h3 className="text-2xl font-semibold text-blue-400 mb-4">Submission Received!</h3>
            <p className="text-gray-300 whitespace-pre-wrap">{submissionResponse}</p>
            <button
                onClick={() => setSubmissionResponse(null)}
                className="mt-6 bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition-colors"
            >
                Submit Another Tool
            </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="bg-gray-900/50 border border-gray-800 rounded-lg p-8 space-y-6">
          <div>
            <label htmlFor="toolName" className="block text-sm font-medium text-gray-300 mb-2">Tool Name</label>
            <input
              type="text"
              id="toolName"
              value={toolName}
              onChange={(e) => setToolName(e.target.value)}
              className="block w-full bg-gray-800/70 border border-gray-700 rounded-md py-2 px-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="e.g., Super Image Generator"
            />
          </div>
          <div>
            <label htmlFor="toolUrl" className="block text-sm font-medium text-gray-300 mb-2">Official Website URL</label>
            <input
              type="text"
              id="toolUrl"
              value={toolUrl}
              onChange={(e) => setToolUrl(e.target.value)}
              className="block w-full bg-gray-800/70 border border-gray-700 rounded-md py-2 px-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="https://example.com"
            />
          </div>
          <div>
            <label htmlFor="description" className="block text-sm font-medium text-gray-300 mb-2">Short Description (Optional)</label>
            <textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              className="block w-full bg-gray-800/70 border border-gray-700 rounded-md py-2 px-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="What makes this tool special?"
            />
          </div>

          {error && <p className="text-red-400 text-sm">{error}</p>}

          <div className="pt-2">
            <button
              type="submit"
              disabled={isLoading}
              className="w-full flex justify-center items-center bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg transition-colors disabled:bg-gray-600 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <>
                  {/* FIX: Corrected typo in viewBox attribute */}
                  <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Submitting...
                </>
              ) : (
                'Submit Tool'
              )}
            </button>
          </div>
        </form>
      )}
    </div>
  );
};

export default SubmitToolPage;