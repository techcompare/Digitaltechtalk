import React, { useState } from 'react';
import ToolCard from '../components/ToolCard';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';
import { searchAITools } from '../services/geminiService';
import type { Tool, GroundingChunk } from '../types';

const SearchPage: React.FC = () => {
  const [searchResults, setSearchResults] = useState<Tool[] | null>(null);
  const [sources, setSources] = useState<GroundingChunk[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeSearchTerm, setActiveSearchTerm] = useState<string>('');

  const handleSearchSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedQuery = searchQuery.trim();
    if (!trimmedQuery) return;

    setIsLoading(true);
    setError(null);
    setSearchResults(null);
    setSources([]);
    setActiveSearchTerm(trimmedQuery);

    try {
      const { tools: searchedTools, sources: searchSources } = await searchAITools(trimmedQuery);
      setSearchResults(searchedTools);
      setSources(searchSources);
    } catch (err) {
      if (err instanceof Error) setError(err.message);
      else setError('An unknown search error occurred.');
    } finally {
      setIsLoading(false);
    }
  };
  
  const renderContent = () => {
    if (isLoading) return <LoadingSpinner />;
    if (error) return <ErrorMessage message={error} />;
    
    if (searchResults === null) {
      return (
        <div className="text-center py-16 text-gray-500">
          <p>Use the search bar above to find AI tools from across the web.</p>
        </div>
      );
    }

    if (searchResults.length === 0) {
      return (
        <div className="text-center py-16">
          <h2 className="text-2xl font-semibold text-gray-300">No Tools Found</h2>
          <p className="text-gray-500 mt-2">
            Your search for "{activeSearchTerm}" did not return any results.
          </p>
        </div>
      );
    }

    return (
      <>
        <h2 className="text-2xl font-bold text-gray-100 mb-6 text-center">
            Search Results for "{activeSearchTerm}"
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {searchResults.map((tool, index) => (
            <ToolCard key={`${tool.name}-${tool.websiteUrl}`} tool={tool} index={index} />
          ))}
        </div>
      </>
    );
  };

  return (
    <div>
      <form onSubmit={handleSearchSubmit} className="mb-10 max-w-2xl mx-auto">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <svg className="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
              <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
            </svg>
          </div>
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search Google for any AI tool..."
            className="block w-full bg-gray-900/70 border border-gray-700 rounded-md py-3 pl-10 pr-4 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
            aria-label="Search for AI tools"
          />
        </div>
      </form>
      
      {renderContent()}

      {searchResults !== null && !isLoading && !error && sources.length > 0 && (
        <div className="mt-16 max-w-4xl mx-auto text-center">
          <div className="border-t border-gray-800 pt-6">
            <h3 className="text-md font-semibold text-gray-400 mb-4">
              Information Sourced From
            </h3>
            <ul className="flex flex-wrap justify-center gap-x-6 gap-y-2">
              {sources.map((source, index) => source.web && source.web.uri && (
                <li key={index}>
                  <a href={source.web.uri} target="_blank" rel="noopener noreferrer" className="text-sm text-blue-500 hover:text-blue-400 hover:underline transition-colors" title={source.web.title}>
                    {source.web.title || new URL(source.web.uri).hostname}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};

export default SearchPage;