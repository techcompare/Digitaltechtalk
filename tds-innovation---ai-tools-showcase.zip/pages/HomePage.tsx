import React, { useState, useEffect } from 'react';
import ToolCard from '../components/ToolCard';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';
import { fetchTrendingAITools } from '../services/geminiService';
import type { Tool } from '../types';

const HomePage: React.FC = () => {
  const [trendingTools, setTrendingTools] = useState<Tool[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadTrendingTools = async () => {
      try {
        setIsLoading(true);
        setError(null);
        const fetchedTools = await fetchTrendingAITools();
        setTrendingTools(fetchedTools);
      } catch (err) {
        if (err instanceof Error) setError(err.message);
        else setError('An unknown error occurred.');
      } finally {
        setIsLoading(false);
      }
    };
    
    loadTrendingTools();
  }, []);

  const renderContent = () => {
    if (isLoading) return <LoadingSpinner />;
    if (error) return <ErrorMessage message={error} />;
    
    if (trendingTools.length === 0) {
      return (
        <div className="text-center py-16">
          <h2 className="text-2xl font-semibold text-gray-300">No Tools Found</h2>
          <p className="text-gray-500 mt-2">Could not fetch trending tools at the moment.</p>
        </div>
      );
    }
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {trendingTools.map((tool, index) => (
          <ToolCard key={`${tool.name}-${tool.websiteUrl}`} tool={tool} index={index} />
        ))}
      </div>
    );
  };

  return (
    <div>
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold text-gray-100">Top Trending AI Tools</h2>
        <p className="text-gray-400 mt-2">Discover the most popular and innovative AI tools, curated daily.</p>
      </div>
      {renderContent()}
    </div>
  );
};

export default HomePage;