import { GoogleGenAI, Type } from "@google/genai";
import type { Tool, GroundingChunk } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

export async function fetchTrendingAITools(): Promise<Tool[]> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-flash-lite-latest",
      contents: "List the top 12 most popular and trending AI tools across different categories like text generation, image generation, code assistance, and video creation. For each tool, provide its name, a short, compelling description (one sentence), its main category, its official website URL, a single keyword for an icon, and its pricing model (e.g., 'Free', 'Freemium', 'Paid', 'Free Trial').",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING, description: "The official name of the AI tool." },
              description: { type: Type.STRING, description: "A short, one-sentence compelling description of the tool." },
              category: { type: Type.STRING, description: "The primary category of the tool." },
              websiteUrl: { type: Type.STRING, description: "The official website URL of the tool." },
              icon: { type: Type.STRING, description: "A single keyword representing the tool's function for icon mapping." },
              pricing: { type: Type.STRING, description: "The pricing model of the tool (e.g., 'Free', 'Freemium', 'Paid', 'Free Trial')." }
            },
            required: ["name", "description", "category", "websiteUrl", "icon", "pricing"]
          }
        },
      },
    });

    const jsonText = response.text.trim();
    const tools = JSON.parse(jsonText);
    return tools as Tool[];
  } catch (error) {
    console.error("Error fetching AI tools:", error);
    throw new Error("Failed to fetch trending AI tools. The API may be busy. Please try again later.");
  }
}

export async function searchAITools(query: string): Promise<{ tools: Tool[], sources: GroundingChunk[] }> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-flash-lite-latest",
      contents: `Find AI tools related to "${query}". For each tool, provide its name, a short, compelling description (one sentence), its main category, its official website URL, a single keyword for an icon, and its pricing model (e.g., 'Free', 'Freemium', 'Paid', 'Free Trial'). Respond ONLY with a JSON array of objects. Each object must have these properties: "name", "description", "category", "websiteUrl", "icon", "pricing". Do not include any text before or after the JSON array.`,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    const rawText = response.text.trim();
    // Sanitize the response to ensure it's valid JSON
    const jsonText = rawText.replace(/^```json|```$/g, '').trim();
    
    if (!jsonText.startsWith('[')) {
        throw new Error("API returned a non-JSON response.");
    }

    const tools = JSON.parse(jsonText);
    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];

    return { tools: tools as Tool[], sources };
  } catch (error) {
    if (error instanceof SyntaxError) {
        console.error("Failed to parse JSON from API response.", error);
        throw new Error("The search results returned were in an invalid format. Please try again.");
    }
    console.error(`Error searching for AI tools with query "${query}":`, error);
    throw new Error(`Failed to search for AI tools. Please try a different search term.`);
  }
}

export async function generateSubmissionResponse(toolName: string): Promise<string> {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-flash-lite-latest",
            contents: `The user has just submitted a new AI tool to our showcase called "${toolName}". Write a short, encouraging, and creative thank you message for this submission. Make it sound exciting and appreciative.`,
        });
        return response.text;
    } catch (error) {
        console.error("Error generating submission response:", error);
        return "Thank you for your submission! We've received it and will review it shortly.";
    }
}